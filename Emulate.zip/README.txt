\_________________________________________________________________________________________________________/  
  Emulate Client is a github open source roblox tool that compiles mods from popular roblox clients such as: 
   - Krnl
   - Synapse
   - magnusnight
   - scielest
 
  Our client contains the mods:
   - keyless
   - wh
   - built in macro register
   - Aimbot
   - ESP
   - Fly
   - God mode
   - No legs
   - High Hips
   - Float
   - Infinite Jump
   - Flashlight
   - Full UI customizability

  ALL CREDITS TO:
  https://github.com/Zipped1337/Emulate

  ANY REPOST SHOULD BE REPORTED TO THE COMMENTS OF THIS GITHUB
 _________________________________________________________________________________________________________
/                                                                                                         \
